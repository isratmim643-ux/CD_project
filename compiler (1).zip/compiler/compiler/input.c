Begin
#include <stdio.h>
int main() {
    int x = 5;
    print("Hello\n");
    return x;
}
End

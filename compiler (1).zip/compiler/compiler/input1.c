#include<stdio.h>
#include<string.h>
int main() {
    int a;
    int x=1;
    int y=2;
    int z=3;
    x=3;
    y=10;
    z=5;
    if(x>5) {
        for(int k=0; k<10; k++) {
            y = x+3;
            print("Hello!");
        }
    } else {
        int idx = 1;
    }
    for(int i=0; i<10; i++) {
        print("Hello World!");
        scan("%d", &x);
        if (x>5) {
            print("Hello to compile");
        }
        for(int j=0; j<z; j++) {
            a=1;
        }
    } 
    return 1;
}

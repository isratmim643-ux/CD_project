#include <stdio.h>

int main() {
    dec _input3k = 10..
    dec _result4m = 2..
    printf("%d\n", _rt4c)..
    return 0..
}
// over here
